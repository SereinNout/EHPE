# EHPE - PyTorch 

## Configure dataset paths
Edit `configs/default.yaml`:
- interhand.image_root
- interhand.ann_path

## NOTE
 Supplementary information will add later.
