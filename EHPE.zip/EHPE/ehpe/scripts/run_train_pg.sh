#!/usr/bin/env bash
python -m ehpe.train.train_pg
