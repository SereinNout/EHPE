from .interhand2p6m import InterHand2p6M
